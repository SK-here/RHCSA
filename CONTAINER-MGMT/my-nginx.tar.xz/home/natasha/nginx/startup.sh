#!/bin/bash

if [ ! -z "$CUSTOM_MSG" ] && [ ! -f /CUSTOM_MSG.done ]; then
	echo -e "Custom Messahe: $CUSTOM_MSG" >> /usr/share/nginx/html/index.html
	touch /CUSTOM_MSG.done
fi

exec /usr/sbin/nginx -g "daemon off;"
